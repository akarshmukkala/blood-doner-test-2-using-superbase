Docker deployment

1) Create a `.env` file next to `docker-compose.yml` with the following keys:

MONGO_URI=mongodb://your_mongo_host:27017/blood_donor_db
JWT_SECRET=your_jwt_secret
ALLOWED_ORIGINS=http://your-frontend.example.com,http://localhost

2) Build and run:
```bash
docker compose up --build -d
```

3) Access the frontend at `http://<server-ip>/B_index.html` and backend at `http://<server-ip>:5000`.

Notes:
- For production, run Docker behind a reverse proxy (nginx) and secure with TLS.
- If you deploy to a cloud VM, ensure ports 80 and 5000 are open.
- You may prefer to serve only the frontend publicly and keep the backend on a private port with a reverse proxy.
