const express = require('express');
const cors = require('cors');
const path = require('path');
require('dotenv').config();

const app = express();
const allowedOrigins = (process.env.ALLOWED_ORIGINS || 'http://localhost:3000,http://localhost:5000,http://localhost:5173,http://localhost:5500,http://127.0.0.1:5500').split(',').filter(Boolean);
app.use(cors({origin:(origin,cb)=>{if(!origin)return cb(null,true); if(allowedOrigins.includes('*')||allowedOrigins.includes(origin)||origin.endsWith('.netlify.app'))return cb(null,true); return cb(new Error('CORS policy: Origin not allowed'));},methods:['GET','POST','PUT','PATCH','DELETE','OPTIONS'],allowedHeaders:['Content-Type','Authorization','Accept']}));
app.use(express.json());
app.use(express.static(path.join(__dirname,'../')));
app.get('/',(req,res)=>res.sendFile(path.join(__dirname,'../index.html')));
app.get('/B_index.html',(req,res)=>res.sendFile(path.join(__dirname,'../B_index.html')));
app.use('/api/auth',require('./routes/authRoutes'));
app.use('/api',require('./routes/apiRoutes'));
const PORT=process.env.PORT||5000;
app.listen(PORT,()=>console.log(`Backend running on port ${PORT} with Supabase PostgreSQL`));
