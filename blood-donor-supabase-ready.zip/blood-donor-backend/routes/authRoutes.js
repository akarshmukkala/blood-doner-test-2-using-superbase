const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { supabase, findByEmail, mapUser } = require('../user');
const router = express.Router();

router.post('/register', async (req, res) => {
  try {
    const { name, email, password, bloodGroup, city, state, phone, availability } = req.body;
    if (!name || !email || !password || !bloodGroup || !city || !state || !phone) return res.status(400).json({ message: 'Please provide all required fields' });
    if (password.length < 6) return res.status(400).json({ message: 'Password must be at least 6 characters' });
    const existing = await findByEmail(email);
    if (existing) return res.status(400).json({ message: 'User already exists' });
    const password_hash = await bcrypt.hash(password, 12);
    const { data, error } = await supabase.from('users').insert({ name, email: email.toLowerCase(), password_hash, blood_group: bloodGroup, city, state, phone, availability: availability || 'available' }).select('*').single();
    if (error) throw error;
    const token = jwt.sign({ id: data.id }, process.env.JWT_SECRET || 'dev-secret', { expiresIn: '7d' });
    res.status(201).json({ message: 'User registered successfully', token, user: mapUser(data) });
  } catch (error) { res.status(500).json({ message: error.message || 'Registration failed' }); }
});

router.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    if (!email || !password) return res.status(400).json({ message: 'Email and password are required' });
    const user = await findByEmail(email);
    if (!user) return res.status(400).json({ message: 'Invalid credentials' });
    const ok = await bcrypt.compare(password, user.password_hash);
    if (!ok) return res.status(400).json({ message: 'Invalid credentials' });
    const token = jwt.sign({ id: user.id }, process.env.JWT_SECRET || 'dev-secret', { expiresIn: '7d' });
    res.json({ message: 'Login successful', token, user: mapUser(user) });
  } catch (error) { res.status(500).json({ message: error.message || 'Login failed' }); }
});
module.exports = router;
