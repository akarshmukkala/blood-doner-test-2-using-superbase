const router = require('express').Router();
const { supabase } = require('../user');
const { protect } = require('../middleware/authMiddleware');

router.get('/donors', async (req, res) => {
  try {
    let q = supabase.from('users').select('id,name,email,blood_group,city,state,phone,availability,avatar,distance,last_donation');
    if (req.query.bloodGroup) q = q.eq('blood_group', req.query.bloodGroup);
    if (req.query.city) q = q.ilike('city', `%${req.query.city}%`);
    if (req.query.state) q = q.ilike('state', `%${req.query.state}%`);
    if (req.query.availability) q = q.eq('availability', req.query.availability);
    const { data, error } = await q.order('created_at', { ascending: false });
    if (error) throw error;
    res.json((data || []).map(u => ({...u, bloodGroup:u.blood_group, lastDonation:u.last_donation})));
  } catch (e) { res.status(500).json({ message: e.message }); }
});

router.get('/services', async (_req,res) => { const {data,error}=await supabase.from('services').select('*').eq('active',true).order('created_at'); if(error)return res.status(500).json({message:error.message}); res.json(data||[]); });

router.post('/bookings', protect, async (req,res) => {
  try { const {serviceId,address,description,bookingTime}=req.body; if(!serviceId||!address||!description||!bookingTime)return res.status(400).json({message:'Please provide all booking fields'});
    const {data:service}=await supabase.from('services').select('id,base_price,name').eq('id',serviceId).maybeSingle();
    const {data,error}=await supabase.from('bookings').insert({customer_id:req.user.id,service_id:serviceId,address,description,booking_time:bookingTime,amount:service?.base_price||0}).select('*').single();
    if(error)throw error; res.status(201).json({...data,id:data.id,serviceName:service?.name});
  } catch(e){res.status(500).json({message:e.message});}
});

router.get('/bookings/user', protect, async (req,res)=>{
  const {data,error}=await supabase.from('bookings').select('*,services(name)').eq('customer_id',req.user.id).order('created_at',{ascending:false});
  if(error)return res.status(500).json({message:error.message});
  res.json((data||[]).map(b=>({...b,serviceName:b.services?.name||'Service'})));
});
router.get('/bookings/:id', protect, async (req,res)=>{
  const {data,error}=await supabase.from('bookings').select('*,services(name)').eq('id',req.params.id).eq('customer_id',req.user.id).maybeSingle();
  if(error)return res.status(500).json({message:error.message}); if(!data)return res.status(404).json({message:'Booking not found'}); res.json({...data,serviceName:data.services?.name||'Service'});
});

router.get('/matching/bookings/:bookingId', protect, async (req,res)=>{
  const {data:booking}=await supabase.from('bookings').select('id').eq('id',req.params.bookingId).eq('customer_id',req.user.id).maybeSingle();
  if(!booking)return res.status(404).json({message:'Booking not found'});
  const {data,error}=await supabase.from('booking_matches').select('match_score,workers(id,name,skill_level,hourly_rate,rating,coop_tenure,verified)').eq('booking_id',req.params.bookingId).order('match_score',{ascending:false});
  if(error)return res.status(500).json({message:error.message});
  res.json((data||[]).map(m=>({workerId:m.workers?.id,name:m.workers?.name,matchScore:m.match_score,skillLevel:m.workers?.skill_level,hourlyRate:m.workers?.hourly_rate,rating:m.workers?.rating,coopTenure:m.workers?.coop_tenure,verified:m.workers?.verified})));
});
router.get('/bookings/:bookingId/matches', protect, async (req,res)=>{ req.params.bookingId=req.params.bookingId; const {data:booking}=await supabase.from('bookings').select('id').eq('id',req.params.bookingId).eq('customer_id',req.user.id).maybeSingle(); if(!booking)return res.status(404).json({message:'Booking not found'}); const {data,error}=await supabase.from('booking_matches').select('match_score,workers(id,name,skill_level,hourly_rate,rating,coop_tenure,verified)').eq('booking_id',req.params.bookingId).order('match_score',{ascending:false}); if(error)return res.status(500).json({message:error.message}); res.json((data||[]).map(m=>({workerId:m.workers?.id,name:m.workers?.name,matchScore:m.match_score,skillLevel:m.workers?.skill_level,hourlyRate:m.workers?.hourly_rate,rating:m.workers?.rating,coopTenure:m.workers?.coop_tenure,verified:m.workers?.verified}))); });

router.patch('/jobs/:jobId/status', protect, async (req,res)=>{ const {status}=req.body; const {data,error}=await supabase.from('bookings').update({status}).eq('id',req.params.jobId).eq('customer_id',req.user.id).select().maybeSingle(); if(error)return res.status(500).json({message:error.message}); if(!data)return res.status(404).json({message:'Job not found'}); res.json(data); });

router.post('/payments', protect, async(req,res)=>{ const {bookingId,amount}=req.body; const {data:booking}=await supabase.from('bookings').select('id,amount').eq('id',bookingId).eq('customer_id',req.user.id).maybeSingle(); if(!booking)return res.status(404).json({message:'Booking not found'}); const {data,error}=await supabase.from('payments').insert({booking_id:bookingId,amount:Number(amount||booking.amount||0),status:'CREATED'}).select().single(); if(error)return res.status(500).json({message:error.message}); res.status(201).json(data); });
router.patch('/payments/:paymentId/pay', protect, async(req,res)=>{ const {data:payment}=await supabase.from('payments').select('id,booking_id').eq('id',req.params.paymentId).maybeSingle(); if(!payment)return res.status(404).json({message:'Payment not found'}); const {data:booking}=await supabase.from('bookings').select('id').eq('id',payment.booking_id).eq('customer_id',req.user.id).maybeSingle(); if(!booking)return res.status(403).json({message:'Not allowed'}); const {data,error}=await supabase.from('payments').update({status:'PAID',paid_at:new Date().toISOString()}).eq('id',payment.id).select().single(); if(error)return res.status(500).json({message:error.message}); res.json(data); });
router.post('/welfare/payment/:paymentId', protect, async(req,res)=>{ const {data:payment}=await supabase.from('payments').select('id,amount,booking_id').eq('id',req.params.paymentId).maybeSingle(); if(!payment)return res.status(404).json({message:'Payment not found'}); const {data:booking}=await supabase.from('bookings').select('id').eq('id',payment.booking_id).eq('customer_id',req.user.id).maybeSingle(); if(!booking)return res.status(403).json({message:'Not allowed'}); const amount=Number(payment.amount)*0.05; const {data,error}=await supabase.from('welfare_contributions').upsert({payment_id:payment.id,percentage:5,amount,status:'DEPOSITED'},{onConflict:'payment_id'}).select().single(); if(error)return res.status(500).json({message:error.message}); res.json({...data,welfareAmount:amount}); });
router.post('/ratings', protect, async(req,res)=>{ const {bookingId,rating,comment}=req.body; const {data:booking}=await supabase.from('bookings').select('id,assigned_worker_id').eq('id',bookingId).eq('customer_id',req.user.id).maybeSingle(); if(!booking)return res.status(404).json({message:'Booking not found'}); const {data,error}=await supabase.from('ratings').insert({booking_id:bookingId,customer_id:req.user.id,worker_id:booking.assigned_worker_id,rating,comment}).select().single(); if(error)return res.status(500).json({message:error.message}); res.status(201).json(data); });

module.exports=router;
