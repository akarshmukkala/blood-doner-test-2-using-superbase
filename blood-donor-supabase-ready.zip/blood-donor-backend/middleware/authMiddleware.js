const jwt = require('jsonwebtoken');
const { findById, mapUser } = require('../user');

const protect = async (req, res, next) => {
  let token = req.headers.authorization;
  if (!token || !token.startsWith('Bearer ')) return res.status(401).json({ message: 'Not authorized, no token' });
  try {
    token = token.split(' ')[1];
    const decoded = jwt.verify(token, process.env.JWT_SECRET || 'dev-secret');
    const user = await findById(decoded.id);
    if (!user) return res.status(401).json({ message: 'User not found' });
    req.user = mapUser(user);
    req.userRecord = user;
    next();
  } catch (error) {
    return res.status(401).json({ message: 'Not authorized, token failed' });
  }
};
module.exports = { protect };
