const { createClient } = require('@supabase/supabase-js');
require('dotenv').config();

const url = process.env.SUPABASE_URL;
const key = process.env.SUPABASE_SECRET_KEY || process.env.SUPABASE_SERVICE_ROLE_KEY;

if (!url || !key) {
  console.warn('Supabase backend credentials are missing. Set SUPABASE_URL and SUPABASE_SECRET_KEY in .env.');
}

const supabase = createClient(url || 'https://placeholder.supabase.co', key || 'placeholder', {
  auth: { autoRefreshToken: false, persistSession: false }
});

module.exports = supabase;
