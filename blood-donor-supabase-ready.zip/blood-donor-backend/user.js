const supabase = require('./config/supabase');

function mapUser(row) {
  if (!row) return null;
  return {
    id: row.id, name: row.name, email: row.email, bloodGroup: row.blood_group,
    city: row.city, state: row.state, phone: row.phone, availability: row.availability || 'available',
    avatar: row.avatar || 'https://via.placeholder.com/150', distance: row.distance || '5 km',
    lastDonation: row.last_donation
  };
}

async function findById(id) {
  const { data, error } = await supabase.from('users').select('*').eq('id', id).maybeSingle();
  if (error) throw error;
  return data;
}

async function findByEmail(email) {
  const { data, error } = await supabase.from('users').select('*').ilike('email', email).maybeSingle();
  if (error) throw error;
  return data;
}

module.exports = { supabase, mapUser, findById, findByEmail };
