Netlify deployment steps for the frontend

This project contains a static frontend (root HTML/CSS/JS) and an Express backend under `blood-donor-backend`.

Options:
1) Deploy frontend to Netlify and host backend elsewhere (recommended for simplicity).
2) Deploy the backend on a Node host (Vercel, Heroku, DigitalOcean) and set `ALLOWED_ORIGINS` accordingly.

Quick Netlify UI deploy (recommended):
- Replace `_redirects` or `netlify.toml` API target with your backend host (e.g. https://api.yourdomain.com).
- In Netlify, create a new site > Import from Git > select repo.
- **Build settings**: No build command (leave blank). **Publish directory**: `.`
- Add `_redirects` to repository root (already present).
- Deploy site.

Netlify CLI deploy (direct from local):
```bash
npm install -g netlify-cli
netlify login
# link or create a new site interactively
netlify init
# Deploy draft
netlify deploy --dir=. --site your-site-id
# Or directly to production
netlify deploy --prod --dir=. --site your-site-id
```

Environment & backend:
- The frontend uses relative API paths (`/api/...`) so the backend must be available under the same origin or Netlify must redirect `/api/*` to your backend host using the `_redirects` file or `netlify.toml`.
- Update `_redirects` and `netlify.toml` `to` value to your backend host before deploy.

Backend hosting suggestions:
- Use Vercel, Render, Heroku, or digitalocean App Platform for the Express backend.
- Set env vars on the backend host: `MONGO_URI`, `JWT_SECRET`, `ALLOWED_ORIGINS` (include your Netlify site URL), `PORT` (if required).

Verifying after deploy:
- Visit the deployed Netlify site URL and open DevTools > Network.
- Submit the `Create Account` form and verify the POST goes to `/api/auth/register` and receives `201`.
- If requests are routed to external backend, ensure CORS allows the Netlify origin.
