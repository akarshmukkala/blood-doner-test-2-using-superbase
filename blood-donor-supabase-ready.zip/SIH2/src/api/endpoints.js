import apiClient from './client';

// Authentication Endpoints
export const loginUser = async (credentials) => {
  return await apiClient.post('/auth/login', credentials);
};

export const registerUser = async (userData) => {
  return await apiClient.post('/auth/register', userData);
};

// Services Endpoints
export const getServices = async () => {
  return await apiClient.get('/services');
};

// Bookings Endpoints (Strict Rule: NEVER send customerId in payload)
export const createBooking = async (bookingData) => {
  // bookingData: { serviceId, address, description, bookingTime }
  return await apiClient.post('/bookings', bookingData);
};

export const getUserBookings = async () => {
  return await apiClient.get('/bookings/user');
};

export const getBookingDetails = async (bookingId) => {
  return await apiClient.get(`/bookings/${bookingId}`);
};

// Matching Engine Endpoints
export const getMatchesForBooking = async (bookingId) => {
  try {
    return await apiClient.get(`/matching/bookings/${bookingId}`);
  } catch (err) {
    // Fallback if matching path is configured under bookings
    return await apiClient.get(`/bookings/${bookingId}/matches`);
  }
};

// Jobs Endpoints
export const updateJobStatus = async (jobId, status) => {
  return await apiClient.patch(`/jobs/${jobId}/status`, { status });
};

// Payments Endpoints
export const createPayment = async (paymentData) => {
  // paymentData: { bookingId, amount }
  return await apiClient.post('/payments', paymentData);
};

export const processPayment = async (paymentId) => {
  return await apiClient.patch(`/payments/${paymentId}/pay`);
};

// Welfare Contribution Endpoint (CRITICAL: Allocates 5% to Worker Welfare Pool)
export const contributeWelfare = async (paymentId) => {
  return await apiClient.post(`/welfare/payment/${paymentId}`);
};

// Ratings Endpoints
export const submitRating = async (ratingData) => {
  // ratingData: { bookingId, rating, comment }
  return await apiClient.post('/ratings', ratingData);
};
