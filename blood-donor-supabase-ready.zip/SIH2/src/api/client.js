import axios from 'axios';

// Create base Axios instance
const apiClient = axios.create({
  baseURL: '/api',
  headers: {
    'Content-Type': 'application/json',
  },
  timeout: 10000,
});

// Request Interceptor: Attach JWT Token from localStorage
apiClient.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// Response Interceptor: Directly return response.data (raw DTO/Array) and handle errors
apiClient.interceptors.response.use(
  (response) => {
    // Spring Boot returns raw DTOs/Arrays in response.data
    return response.data;
  },
  (error) => {
    if (error.response) {
      // 401 Unauthorized: Clear local auth state & redirect
      if (error.response.status === 401) {
        localStorage.removeItem('token');
        localStorage.removeItem('user');
        if (window.location.pathname !== '/login') {
          window.location.href = '/login';
        }
      }

      // Backend Error Schema: { timestamp, status, error, message, path, fieldErrors }
      const backendError = error.response.data || {};
      
      let message = backendError.message;
      if (!message || typeof message !== 'string' || message.includes('Access Error')) {
        if (error.response.status === 404) {
          message = `Backend API route not found (HTTP 404). Please check that your Spring Boot server is running on http://localhost:8080 (Note: Port 8080 is currently used by ApplicationWebServer.exe).`;
        } else {
          message = `Backend request failed with status ${error.response.status}.`;
        }
      }

      const normalizedError = {
        status: error.response.status,
        error: backendError.error || 'API Error',
        message: message,
        fieldErrors: backendError.fieldErrors || null,
        raw: backendError,
      };

      return Promise.reject(normalizedError);
    }

    // Network error (server offline or proxy connection refused)
    const customError = {
      status: 0,
      error: 'Network Error',
      message: 'Unable to connect to Spring Boot backend at http://localhost:8080. Please start your Spring Boot application.',
      fieldErrors: null,
    };

    return Promise.reject(customError);
  }
);

export default apiClient;
