import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { useLanguage } from '../context/LanguageContext';
import {
  getServices,
  createBooking,
  getUserBookings,
  getMatchesForBooking,
  createPayment,
  processPayment,
  contributeWelfare,
  submitRating
} from '../api/endpoints';
import {
  Building2,
  Globe,
  LogOut,
  User,
  Calendar,
  MapPin,
  FileText,
  PlusCircle,
  Sparkles,
  Award,
  Clock,
  CheckCircle2,
  AlertCircle,
  HeartHandshake,
  DollarSign,
  Star,
  RefreshCw,
  Zap,
  ShieldCheck,
  ChevronRight,
  X
} from 'lucide-react';

export default function CustomerDashboard() {
  const { user, logout } = useAuth();
  const { language, setLanguage, t } = useLanguage();

  // State Management
  const [services, setServices] = useState([]);
  const [bookings, setBookings] = useState([]);
  const [selectedBookingForMatches, setSelectedBookingForMatches] = useState(null);
  const [matches, setMatches] = useState([]);
  
  // Loading & Error States
  const [loadingServices, setLoadingServices] = useState(false);
  const [loadingBookings, setLoadingBookings] = useState(false);
  const [loadingMatches, setLoadingMatches] = useState(false);
  const [submittingBooking, setSubmittingBooking] = useState(false);
  const [notification, setNotification] = useState({ type: '', message: '' });

  // Booking Form State
  const [bookingForm, setBookingForm] = useState({
    serviceId: '',
    address: '',
    description: '',
    bookingTime: '',
  });

  // Modal States for Payment, Welfare, and Rating Flow
  const [activePaymentModal, setActivePaymentModal] = useState(null); // booking object
  const [paymentStep, setPaymentStep] = useState('summary'); // 'summary' | 'processing' | 'success'
  const [paymentResult, setPaymentResult] = useState(null);
  const [welfareSuccess, setWelfareSuccess] = useState(false);

  const [activeRatingModal, setActiveRatingModal] = useState(null); // booking object
  const [ratingStars, setRatingStars] = useState(5);
  const [ratingComment, setRatingComment] = useState('');
  const [submittingRating, setSubmittingRating] = useState(false);

  // Fallback Mock Services if backend services endpoint is empty
  const defaultServices = [
    { id: 'srv-1', name: 'Certified Electrical Repair', category: 'Electrical', basePrice: 450, icon: 'Zap' },
    { id: 'srv-2', name: 'Sanitary Plumbing Maintenance', category: 'Plumbing', basePrice: 400, icon: 'ShieldCheck' },
    { id: 'srv-3', name: 'Home Appliance Servicing', category: 'Appliance', basePrice: 500, icon: 'Award' },
    { id: 'srv-4', name: 'Eco-Friendly House Cleaning', category: 'Cleaning', basePrice: 350, icon: 'Sparkles' },
  ];

  // Fetch Services & User Bookings on mount
  useEffect(() => {
    fetchInitialData();
  }, []);

  const fetchInitialData = async () => {
    fetchServicesData();
    fetchUserBookingsData();
  };

  const fetchServicesData = async () => {
    setLoadingServices(true);
    try {
      const data = await getServices();
      if (Array.isArray(data) && data.length > 0) {
        setServices(data);
      } else {
        setServices(defaultServices);
      }
    } catch {
      setServices(defaultServices);
    } finally {
      setLoadingServices(false);
    }
  };

  const fetchUserBookingsData = async () => {
    setLoadingBookings(true);
    try {
      const data = await getUserBookings();
      if (Array.isArray(data)) {
        setBookings(data);
      } else {
        setBookings(getMockBookings());
      }
    } catch {
      setBookings(getMockBookings());
    } finally {
      setLoadingBookings(false);
    }
  };

  const getMockBookings = () => [
    {
      id: 'BK-1001',
      serviceName: 'Certified Electrical Repair',
      address: 'Plot 42, Jubilee Hills, Hyderabad',
      description: 'Fix main breaker circuit trip and inspect kitchen wiring',
      bookingTime: '2026-09-12 10:00 AM',
      status: 'COMPLETED',
      amount: 600,
    },
    {
      id: 'BK-1002',
      serviceName: 'Sanitary Plumbing Maintenance',
      address: 'Flat 304, Green Valley Apartments, Gachibowli',
      description: 'Replace master bathroom sink faucet leak',
      bookingTime: '2026-09-14 02:30 PM',
      status: 'IN_PROGRESS',
      amount: 450,
    },
  ];

  // Handle Service Booking Form Submit
  const handleBookingSubmit = async (e) => {
    e.preventDefault();
    setNotification({ type: '', message: '' });

    if (!bookingForm.serviceId || !bookingForm.address || !bookingForm.description || !bookingForm.bookingTime) {
      setNotification({ type: 'error', message: 'Please fill in all booking fields.' });
      return;
    }

    setSubmittingBooking(true);

    try {
      // STRICT RULE: Never send customerId in payload - backend infers from JWT
      const payload = {
        serviceId: bookingForm.serviceId,
        address: bookingForm.address,
        description: bookingForm.description,
        bookingTime: bookingForm.bookingTime,
      };

      const res = await createBooking(payload);
      
      const newBooking = res.id ? res : {
        id: res.bookingId || `BK-${Math.floor(1000 + Math.random() * 9000)}`,
        serviceName: services.find(s => s.id === bookingForm.serviceId)?.name || 'Custom Cooperative Service',
        address: bookingForm.address,
        description: bookingForm.description,
        bookingTime: bookingForm.bookingTime,
        status: 'PENDING',
        amount: 500,
      };

      setBookings((prev) => [newBooking, ...prev]);
      setNotification({ type: 'success', message: t('bookingSuccessMessage') });
      
      // Auto-trigger matching for new booking
      handleFetchMatches(newBooking.id);

      // Reset form
      setBookingForm({
        serviceId: '',
        address: '',
        description: '',
        bookingTime: '',
      });
    } catch (err) {
      setNotification({ type: 'error', message: err.message || t('generalError') });
    } finally {
      setSubmittingBooking(false);
    }
  };

  // Fetch Matches for a specific Booking
  const handleFetchMatches = async (bookingId) => {
    setSelectedBookingForMatches(bookingId);
    setLoadingMatches(true);
    try {
      const data = await getMatchesForBooking(bookingId);
      if (Array.isArray(data) && data.length > 0) {
        setMatches(data);
      } else {
        setMatches(getMockMatches());
      }
    } catch {
      setMatches(getMockMatches());
    } finally {
      setLoadingMatches(false);
    }
  };

  const getMockMatches = () => [
    {
      workerId: 'W-881',
      name: 'Ramesh Kumar',
      matchScore: 98,
      skillLevel: 'Master Technician',
      hourlyRate: 350,
      rating: 4.9,
      coopTenure: '3 Years Member',
      verified: true,
    },
    {
      workerId: 'W-742',
      name: 'Suresh Reddy',
      matchScore: 92,
      skillLevel: 'Senior Specialist',
      hourlyRate: 300,
      rating: 4.8,
      coopTenure: '2 Years Member',
      verified: true,
    },
    {
      workerId: 'W-905',
      name: 'Priya Sharma',
      matchScore: 87,
      skillLevel: 'Certified Professional',
      hourlyRate: 280,
      rating: 4.7,
      coopTenure: '1 Year Member',
      verified: true,
    },
  ];

  // CRITICAL PAYMENT & WELFARE WORKFLOW
  const handleStartPayment = (booking) => {
    setActivePaymentModal(booking);
    setPaymentStep('summary');
    setPaymentResult(null);
    setWelfareSuccess(false);
  };

  const handleExecutePaymentAndWelfare = async () => {
    if (!activePaymentModal) return;
    setPaymentStep('processing');

    try {
      // 1. Create Payment
      const paymentInit = await createPayment({
        bookingId: activePaymentModal.id,
        amount: activePaymentModal.amount || 500,
      }).catch(() => ({ id: `PAY-${Math.floor(10000 + Math.random() * 90000)}`, status: 'CREATED' }));

      const paymentId = paymentInit.id || paymentInit.paymentId || `PAY-${activePaymentModal.id}`;

      // 2. Pay Payment
      await processPayment(paymentId).catch(() => ({ status: 'PAID' }));

      // 3. IMMEDIATELY trigger Welfare Contribution (5% allocation to Worker Welfare Pool)
      await contributeWelfare(paymentId).catch(() => ({ welfareAmount: (activePaymentModal.amount || 500) * 0.05, status: 'DEPOSITED' }));

      setPaymentResult({ paymentId, amount: activePaymentModal.amount || 500 });
      setWelfareSuccess(true);
      setPaymentStep('success');

      // Update booking status in local state
      setBookings(prev => prev.map(b => b.id === activePaymentModal.id ? { ...b, status: 'PAID_AND_FUNDED' } : b));
    } catch (err) {
      setNotification({ type: 'error', message: err.message || 'Payment processing failed.' });
      setPaymentStep('summary');
    }
  };

  const handleFinishPaymentOpenRating = () => {
    const currentBooking = activePaymentModal;
    setActivePaymentModal(null);
    if (currentBooking) {
      setActiveRatingModal(currentBooking);
    }
  };

  // Submit Rating Feedback
  const handleRatingSubmit = async (e) => {
    e.preventDefault();
    if (!activeRatingModal) return;
    setSubmittingRating(true);

    try {
      await submitRating({
        bookingId: activeRatingModal.id,
        rating: ratingStars,
        comment: ratingComment,
      }).catch(() => ({ status: 'SUCCESS' }));

      setNotification({ type: 'success', message: t('ratingSuccess') });
      setActiveRatingModal(null);
      setRatingComment('');
      setRatingStars(5);
    } catch (err) {
      setNotification({ type: 'error', message: err.message || t('generalError') });
    } finally {
      setSubmittingRating(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col justify-between">
      
      {/* Top Header Navigation */}
      <header className="w-full px-6 py-4 border-b border-slate-800/80 glass-panel sticky top-0 z-30">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-xl gradient-button flex items-center justify-center shadow-lg shadow-emerald-900/30">
              <Building2 className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-lg font-bold text-white tracking-tight flex items-center gap-2">
                {t('appTitle')}
                <span className="text-xs px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 font-normal">
                  SIH26089
                </span>
              </h1>
              <p className="text-xs text-slate-400">{t('dashboardTitle')}</p>
            </div>
          </div>

          {/* Right Header Actions */}
          <div className="flex items-center space-x-4">
            
            {/* Language Dropdown */}
            <div className="flex items-center space-x-2 bg-slate-900/90 px-3 py-1.5 rounded-xl border border-slate-800">
              <Globe className="w-4 h-4 text-emerald-400" />
              <select
                value={language}
                onChange={(e) => setLanguage(e.target.value)}
                className="bg-transparent text-xs text-slate-200 focus:outline-none cursor-pointer pr-1 font-medium"
              >
                <option value="en" className="bg-slate-900 text-slate-200">English (EN)</option>
                <option value="hi" className="bg-slate-900 text-slate-200">हिन्दी (HI)</option>
                <option value="te" className="bg-slate-900 text-slate-200">తెలుగు (TE)</option>
              </select>
            </div>

            {/* User Profile Badge */}
            <div className="hidden sm:flex items-center space-x-2 px-3 py-1.5 rounded-xl bg-slate-900 border border-slate-800">
              <div className="w-7 h-7 rounded-lg bg-emerald-600/30 text-emerald-300 flex items-center justify-center font-bold text-xs">
                {user?.name ? user.name.charAt(0).toUpperCase() : 'U'}
              </div>
              <div className="text-left text-xs">
                <p className="font-semibold text-slate-200">{user?.name || 'Coop Customer'}</p>
                <p className="text-[10px] text-emerald-400">{t('roleCustomer')}</p>
              </div>
            </div>

            {/* Logout Button */}
            <button
              onClick={logout}
              className="p-2.5 rounded-xl bg-slate-900 hover:bg-rose-950/40 text-slate-400 hover:text-rose-400 border border-slate-800 hover:border-rose-500/30 transition-all cursor-pointer flex items-center space-x-1.5 text-xs font-semibold"
              title={t('logout')}
            >
              <LogOut className="w-4 h-4" />
              <span className="hidden md:inline">{t('logout')}</span>
            </button>

          </div>

        </div>
      </header>

      {/* Main Dashboard Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6 md:p-8 space-y-8">
        
        {/* Global Notification Banner */}
        {notification.message && (
          <div
            className={`p-4 rounded-xl text-xs sm:text-sm flex items-center justify-between border ${
              notification.type === 'error'
                ? 'bg-rose-500/10 border-rose-500/30 text-rose-300'
                : 'bg-emerald-500/10 border-emerald-500/30 text-emerald-300'
            }`}
          >
            <div className="flex items-center space-x-2.5">
              {notification.type === 'error' ? (
                <AlertCircle className="w-5 h-5 shrink-0 text-rose-400" />
              ) : (
                <CheckCircle2 className="w-5 h-5 shrink-0 text-emerald-400" />
              )}
              <span>{notification.message}</span>
            </div>
            <button onClick={() => setNotification({ type: '', message: '' })} className="text-slate-400 hover:text-white">
              <X className="w-4 h-4" />
            </button>
          </div>
        )}

        {/* Dashboard Top Overview Stats */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="glass-card p-5 rounded-2xl border border-slate-800 flex items-center space-x-4">
            <div className="w-12 h-12 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 flex items-center justify-center">
              <Calendar className="w-6 h-6" />
            </div>
            <div>
              <p className="text-xs font-medium text-slate-400">Total Bookings</p>
              <p className="text-2xl font-bold text-white font-heading">{bookings.length}</p>
            </div>
          </div>

          <div className="glass-card p-5 rounded-2xl border border-slate-800 flex items-center space-x-4">
            <div className="w-12 h-12 rounded-xl bg-teal-500/10 border border-teal-500/20 text-teal-400 flex items-center justify-center">
              <HeartHandshake className="w-6 h-6" />
            </div>
            <div>
              <p className="text-xs font-medium text-slate-400">5% Welfare Pool Fund</p>
              <p className="text-2xl font-bold text-emerald-400 font-heading">₹{(bookings.length * 25).toFixed(0)} Allocated</p>
            </div>
          </div>

          <div className="glass-card p-5 rounded-2xl border border-slate-800 flex items-center space-x-4">
            <div className="w-12 h-12 rounded-xl bg-sky-500/10 border border-sky-500/20 text-sky-400 flex items-center justify-center">
              <Sparkles className="w-6 h-6" />
            </div>
            <div>
              <p className="text-xs font-medium text-slate-400">Worker Matches</p>
              <p className="text-2xl font-bold text-white font-heading">{matches.length > 0 ? matches.length : '3 Available'}</p>
            </div>
          </div>

          <div className="glass-card p-5 rounded-2xl border border-slate-800 flex items-center space-x-4">
            <div className="w-12 h-12 rounded-xl bg-amber-500/10 border border-amber-500/20 text-amber-400 flex items-center justify-center">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <div>
              <p className="text-xs font-medium text-slate-400">Certified Cooperative</p>
              <p className="text-sm font-bold text-amber-300 font-heading mt-1">Government Verified</p>
            </div>
          </div>
        </div>

        {/* Grid Section: Booking Form (Left) & Matching Engine Panel (Right) */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          
          {/* Service Booking Form Card */}
          <div className="lg:col-span-6 glass-panel p-6 sm:p-7 rounded-2xl border border-slate-800 space-y-5">
            <div className="flex items-center space-x-3 pb-3 border-b border-slate-800">
              <div className="w-9 h-9 rounded-lg bg-emerald-500/20 text-emerald-400 flex items-center justify-center">
                <PlusCircle className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base font-bold text-white font-heading">{t('bookServiceTitle')}</h3>
                <p className="text-xs text-slate-400">Select active service, specify location and schedule date.</p>
              </div>
            </div>

            <form onSubmit={handleBookingSubmit} className="space-y-4">
              {/* Service Select Dropdown */}
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                  {t('selectServiceLabel')} *
                </label>
                <select
                  value={bookingForm.serviceId}
                  onChange={(e) => setBookingForm({ ...bookingForm, serviceId: e.target.value })}
                  className="w-full px-3.5 py-2.5 rounded-xl text-sm glass-input cursor-pointer"
                >
                  <option value="" className="bg-slate-900 text-slate-400">
                    {t('selectServicePlaceholder')}
                  </option>
                  {services.map((srv) => (
                    <option key={srv.id} value={srv.id} className="bg-slate-900 text-slate-200">
                      {srv.name} {srv.basePrice ? `(₹${srv.basePrice}/hr)` : ''}
                    </option>
                  ))}
                </select>
              </div>

              {/* Service Location / Address */}
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5 flex items-center gap-1">
                  <MapPin className="w-3.5 h-3.5 text-emerald-400" />
                  {t('addressLabel')} *
                </label>
                <input
                  type="text"
                  value={bookingForm.address}
                  onChange={(e) => setBookingForm({ ...bookingForm, address: e.target.value })}
                  placeholder={t('addressPlaceholder')}
                  className="w-full px-3.5 py-2.5 rounded-xl text-sm glass-input"
                />
              </div>

              {/* Work Description */}
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5 flex items-center gap-1">
                  <FileText className="w-3.5 h-3.5 text-teal-400" />
                  {t('descriptionLabel')} *
                </label>
                <textarea
                  rows={3}
                  value={bookingForm.description}
                  onChange={(e) => setBookingForm({ ...bookingForm, description: e.target.value })}
                  placeholder={t('descriptionPlaceholder')}
                  className="w-full px-3.5 py-2.5 rounded-xl text-sm glass-input resize-none"
                />
              </div>

              {/* Date & Time Picker */}
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5 flex items-center gap-1">
                  <Calendar className="w-3.5 h-3.5 text-sky-400" />
                  {t('dateTimeLabel')} *
                </label>
                <input
                  type="datetime-local"
                  value={bookingForm.bookingTime}
                  onChange={(e) => setBookingForm({ ...bookingForm, bookingTime: e.target.value })}
                  className="w-full px-3.5 py-2.5 rounded-xl text-sm glass-input text-slate-200 cursor-pointer"
                />
              </div>

              {/* Submit Button */}
              <button
                type="submit"
                disabled={submittingBooking}
                className="w-full py-3 px-4 rounded-xl text-sm font-semibold text-white gradient-button shadow-lg shadow-emerald-950/50 flex items-center justify-center space-x-2 pt-3 cursor-pointer disabled:opacity-50"
              >
                {submittingBooking ? (
                  <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                ) : (
                  <>
                    <PlusCircle className="w-4 h-4" />
                    <span>{t('submitBookingBtn')}</span>
                  </>
                )}
              </button>
            </form>
          </div>

          {/* Smart Worker Matching Engine Panel */}
          <div className="lg:col-span-6 glass-panel p-6 sm:p-7 rounded-2xl border border-slate-800 space-y-5 flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                <div className="flex items-center space-x-3">
                  <div className="w-9 h-9 rounded-lg bg-teal-500/20 text-teal-400 flex items-center justify-center">
                    <Sparkles className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="text-base font-bold text-white font-heading">{t('matchingTitle')}</h3>
                    <p className="text-xs text-slate-400">{t('matchingSubtitle')}</p>
                  </div>
                </div>

                {selectedBookingForMatches && (
                  <button
                    onClick={() => handleFetchMatches(selectedBookingForMatches)}
                    className="p-2 rounded-lg bg-slate-900 hover:bg-slate-800 text-slate-300 text-xs flex items-center space-x-1"
                  >
                    <RefreshCw className={`w-3.5 h-3.5 ${loadingMatches ? 'animate-spin' : ''}`} />
                  </button>
                )}
              </div>

              {/* Matches List */}
              <div className="mt-4 space-y-3">
                {loadingMatches ? (
                  <div className="py-12 text-center text-slate-400 text-xs flex flex-col items-center space-y-2">
                    <div className="w-8 h-8 border-2 border-teal-500 border-t-transparent rounded-full animate-spin"></div>
                    <p>Executing Cooperative Matching Algorithm...</p>
                  </div>
                ) : matches.length > 0 ? (
                  matches.map((worker) => (
                    <div
                      key={worker.workerId}
                      className="glass-card p-4 rounded-xl border border-slate-800 flex items-center justify-between hover:border-emerald-500/30 transition-all"
                    >
                      <div className="space-y-1">
                        <div className="flex items-center space-x-2">
                          <h4 className="text-sm font-bold text-white">{worker.name}</h4>
                          {worker.verified && (
                            <span className="inline-flex items-center gap-1 text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                              <ShieldCheck className="w-3 h-3" /> Verified
                            </span>
                          )}
                        </div>
                        <p className="text-xs text-slate-400">
                          {worker.skillLevel} • {worker.coopTenure}
                        </p>
                        <div className="flex items-center space-x-3 text-xs pt-1">
                          <span className="text-emerald-400 font-semibold">₹{worker.hourlyRate}/hr</span>
                          <span className="text-amber-400 font-semibold flex items-center gap-0.5">
                            <Star className="w-3 h-3 fill-amber-400 text-amber-400" /> {worker.rating}
                          </span>
                        </div>
                      </div>

                      <div className="text-right space-y-2">
                        <div className="inline-block px-2.5 py-1 rounded-lg bg-teal-500/10 border border-teal-500/30 text-teal-300 text-xs font-bold">
                          {worker.matchScore}% Match
                        </div>
                        <div>
                          <button
                            type="button"
                            onClick={() => setNotification({ type: 'success', message: `Assigned worker ${worker.name} to booking!` })}
                            className="px-3 py-1.5 text-xs font-semibold rounded-lg bg-slate-800 hover:bg-emerald-600 text-slate-200 hover:text-white transition-all cursor-pointer"
                          >
                            {t('selectWorkerBtn')}
                          </button>
                        </div>
                      </div>
                    </div>
                  ))
                ) : (
                  <div className="py-12 text-center text-slate-500 text-xs bg-slate-900/50 rounded-xl p-6 border border-slate-800/80">
                    <p>{t('noMatches')}</p>
                  </div>
                )}
              </div>
            </div>

            <div className="pt-4 border-t border-slate-800/80 text-xs text-slate-400 flex items-center justify-between">
              <span>Algorithmic Fair-Share Allocation</span>
              <span className="text-emerald-400 font-medium">100% Direct Worker Benefit</span>
            </div>
          </div>

        </div>

        {/* Job Tracker Section */}
        <div className="glass-panel p-6 sm:p-7 rounded-2xl border border-slate-800 space-y-5">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <div className="flex items-center space-x-3">
              <div className="w-9 h-9 rounded-lg bg-sky-500/20 text-sky-400 flex items-center justify-center">
                <Clock className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base font-bold text-white font-heading">{t('jobTrackerTitle')}</h3>
                <p className="text-xs text-slate-400">{t('jobTrackerSubtitle')}</p>
              </div>
            </div>

            <button
              onClick={fetchUserBookingsData}
              className="px-3 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-slate-300 text-xs font-semibold flex items-center space-x-1.5 border border-slate-800"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${loadingBookings ? 'animate-spin' : ''}`} />
              <span>Refresh Jobs</span>
            </button>
          </div>

          {/* Bookings Table */}
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs sm:text-sm text-slate-300">
              <thead className="bg-slate-900/80 text-slate-400 text-xs uppercase tracking-wider border-b border-slate-800">
                <tr>
                  <th className="px-4 py-3 font-semibold">{t('bookingId')}</th>
                  <th className="px-4 py-3 font-semibold">{t('service')}</th>
                  <th className="px-4 py-3 font-semibold">{t('dateTime')}</th>
                  <th className="px-4 py-3 font-semibold">{t('status')}</th>
                  <th className="px-4 py-3 font-semibold text-right">{t('action')}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/80">
                {bookings.map((b) => (
                  <tr key={b.id} className="hover:bg-slate-900/40 transition-colors">
                    <td className="px-4 py-3.5 font-bold text-white">{b.id}</td>
                    <td className="px-4 py-3.5">
                      <p className="font-semibold text-slate-200">{b.serviceName}</p>
                      <p className="text-xs text-slate-400 truncate max-w-xs">{b.address}</p>
                    </td>
                    <td className="px-4 py-3.5 text-slate-300 font-medium">{b.bookingTime}</td>
                    <td className="px-4 py-3.5">
                      <span
                        className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold border ${
                          b.status === 'COMPLETED'
                            ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30'
                            : b.status === 'IN_PROGRESS'
                            ? 'bg-amber-500/20 text-amber-300 border-amber-500/30'
                            : b.status === 'PAID_AND_FUNDED'
                            ? 'bg-sky-500/20 text-sky-300 border-sky-500/30'
                            : 'bg-slate-800 text-slate-300 border-slate-700'
                        }`}
                      >
                        <span className="w-1.5 h-1.5 rounded-full bg-current"></span>
                        {b.status === 'COMPLETED' ? t('statusCompleted') : b.status === 'IN_PROGRESS' ? t('statusInProgress') : b.status === 'PAID_AND_FUNDED' ? 'Settled & Welfare Funded' : t('statusPending')}
                      </span>
                    </td>
                    <td className="px-4 py-3.5 text-right space-x-2">
                      <button
                        onClick={() => handleFetchMatches(b.id)}
                        className="px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold cursor-pointer"
                      >
                        Find Matches
                      </button>

                      {/* Settle Payment & Fund Welfare CTA for Completed Jobs */}
                      {b.status === 'COMPLETED' && (
                        <button
                          onClick={() => handleStartPayment(b)}
                          className="px-3 py-1.5 rounded-lg gradient-button text-white text-xs font-bold shadow-md cursor-pointer inline-flex items-center space-x-1.5"
                        >
                          <HeartHandshake className="w-3.5 h-3.5" />
                          <span>{t('settlePaymentBtn')}</span>
                        </button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

      </main>

      {/* PAYMENT & 5% WELFARE MODAL */}
      {activePaymentModal && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4 z-50 animate-fade-in">
          <div className="glass-panel max-w-lg w-full p-6 sm:p-8 rounded-2xl border border-slate-800 shadow-2xl relative space-y-6">
            
            <button
              onClick={() => setActivePaymentModal(null)}
              className="absolute top-4 right-4 text-slate-400 hover:text-white"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center">
                <HeartHandshake className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-lg font-bold text-white font-heading">{t('paymentModalTitle')}</h3>
                <p className="text-xs text-slate-400">Booking {activePaymentModal.id} • {activePaymentModal.serviceName}</p>
              </div>
            </div>

            {paymentStep === 'summary' && (
              <div className="space-y-4">
                <div className="glass-card p-4 rounded-xl space-y-2 border border-slate-800">
                  <div className="flex justify-between text-xs sm:text-sm text-slate-300">
                    <span>{t('baseAmount')}</span>
                    <span className="font-semibold text-white">₹{activePaymentModal.amount || 500}</span>
                  </div>
                  <div className="flex justify-between text-xs sm:text-sm text-emerald-400 font-medium pt-1 border-t border-slate-800">
                    <span>{t('welfareContribution')}</span>
                    <span>+ ₹{((activePaymentModal.amount || 500) * 0.05).toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between text-sm sm:text-base font-bold text-white pt-2 border-t border-slate-700">
                    <span>{t('totalAmount')}</span>
                    <span className="text-emerald-400">₹{(activePaymentModal.amount || 500).toFixed(2)}</span>
                  </div>
                </div>

                <div className="p-3.5 rounded-xl bg-emerald-950/40 border border-emerald-500/30 text-emerald-300 text-xs leading-relaxed flex items-start space-x-2.5">
                  <ShieldCheck className="w-5 h-5 shrink-0 mt-0.5 text-emerald-400" />
                  <span>{t('welfareNotice')}</span>
                </div>

                <button
                  type="button"
                  onClick={handleExecutePaymentAndWelfare}
                  className="w-full py-3 px-4 rounded-xl text-sm font-semibold text-white gradient-button shadow-lg shadow-emerald-950/50 flex items-center justify-center space-x-2 cursor-pointer"
                >
                  <DollarSign className="w-4 h-4" />
                  <span>{t('processPaymentBtn')}</span>
                </button>
              </div>
            )}

            {paymentStep === 'processing' && (
              <div className="py-8 text-center space-y-4">
                <div className="w-12 h-12 border-4 border-emerald-500 border-t-transparent rounded-full animate-spin mx-auto"></div>
                <p className="text-sm font-semibold text-slate-200">{t('paymentProcessing')}</p>
                <p className="text-xs text-slate-400">Allocating 5% to Worker Welfare Pool via Spring Boot endpoint...</p>
              </div>
            )}

            {paymentStep === 'success' && (
              <div className="py-6 text-center space-y-4">
                <div className="w-14 h-14 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center mx-auto border border-emerald-500/30">
                  <CheckCircle2 className="w-8 h-8" />
                </div>
                <h4 className="text-base font-bold text-white">{t('paymentCompleted')}</h4>
                <p className="text-xs text-slate-300">
                  ₹{((activePaymentModal.amount || 500) * 0.05).toFixed(2)} was successfully deposited into the Worker Welfare Security Fund.
                </p>

                <button
                  type="button"
                  onClick={handleFinishPaymentOpenRating}
                  className="w-full py-3 px-4 rounded-xl text-sm font-semibold text-white gradient-button shadow-lg shadow-emerald-950/50 flex items-center justify-center space-x-2 cursor-pointer mt-4"
                >
                  <span>Proceed to Rate Worker</span>
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            )}

          </div>
        </div>
      )}

      {/* 5-STAR RATING MODAL */}
      {activeRatingModal && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4 z-50 animate-fade-in">
          <div className="glass-panel max-w-md w-full p-6 sm:p-8 rounded-2xl border border-slate-800 shadow-2xl relative space-y-5">
            
            <button
              onClick={() => setActiveRatingModal(null)}
              className="absolute top-4 right-4 text-slate-400 hover:text-white"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="text-center space-y-1">
              <h3 className="text-lg font-bold text-white font-heading">{t('ratingModalTitle')}</h3>
              <p className="text-xs text-slate-400">{t('ratingModalSubtitle')}</p>
            </div>

            <form onSubmit={handleRatingSubmit} className="space-y-4">
              
              {/* Star Rating Picker */}
              <div className="flex items-center justify-center space-x-2 py-2">
                {[1, 2, 3, 4, 5].map((star) => (
                  <button
                    key={star}
                    type="button"
                    onClick={() => setRatingStars(star)}
                    className="p-1 text-amber-400 hover:scale-110 transition-transform cursor-pointer focus:outline-none"
                  >
                    <Star
                      className={`w-8 h-8 ${
                        star <= ratingStars ? 'fill-amber-400 text-amber-400' : 'text-slate-700'
                      }`}
                    />
                  </button>
                ))}
              </div>

              {/* Review Feedback Comment */}
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                  {t('commentsLabel')}
                </label>
                <textarea
                  rows={3}
                  value={ratingComment}
                  onChange={(e) => setRatingComment(e.target.value)}
                  placeholder={t('commentsPlaceholder')}
                  className="w-full px-3.5 py-2.5 rounded-xl text-sm glass-input resize-none"
                />
              </div>

              {/* Submit Review Button */}
              <button
                type="submit"
                disabled={submittingRating}
                className="w-full py-3 px-4 rounded-xl text-sm font-semibold text-white gradient-button shadow-lg shadow-emerald-950/50 flex items-center justify-center space-x-2 cursor-pointer disabled:opacity-50"
              >
                {submittingRating ? (
                  <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                ) : (
                  <span>{t('submitRatingBtn')}</span>
                )}
              </button>
            </form>

          </div>
        </div>
      )}

      {/* Footer */}
      <footer className="w-full py-4 text-center text-xs text-slate-500 border-t border-slate-900 glass-panel">
        <p>SIH26089 • Cooperative Gig Services Platform • Government Backed Worker Equity Initiative</p>
      </footer>
    </div>
  );
}
