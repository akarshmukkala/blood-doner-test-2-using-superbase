import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { useLanguage } from '../context/LanguageContext';
import { loginUser, registerUser } from '../api/endpoints';
import { ShieldCheck, UserPlus, LogIn, Globe, AlertCircle, Sparkles, Building2, HeartHandshake, Zap } from 'lucide-react';

export default function AuthPage() {
  const [isLogin, setIsLogin] = useState(true);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    password: '',
  });

  const [loading, setLoading] = useState(false);
  const [globalError, setGlobalError] = useState('');
  const [fieldErrors, setFieldErrors] = useState({});

  const { login } = useAuth();
  const { language, setLanguage, t } = useLanguage();
  const navigate = useNavigate();

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
    if (fieldErrors[name]) {
      setFieldErrors((prev) => ({ ...prev, [name]: null }));
    }
  };

  const validateLocalForm = () => {
    const errors = {};
    if (!isLogin && !formData.name.trim()) {
      errors.name = 'Full name is required';
    }
    if (!formData.email.trim()) {
      errors.email = 'Email address is required';
    } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
      errors.email = 'Please enter a valid email address';
    }
    if (!isLogin) {
      if (!formData.phone.trim()) {
        errors.phone = '10-digit mobile number is required';
      } else if (!/^\d{10}$/.test(formData.phone.trim())) {
        errors.phone = 'Phone number must be exactly 10 numeric digits';
      }
    }
    if (!formData.password) {
      errors.password = 'Password is required';
    } else if (formData.password.length < 6) {
      errors.password = 'Password must be at least 6 characters long';
    }

    setFieldErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setGlobalError('');
    setFieldErrors({});

    if (!validateLocalForm()) return;

    setLoading(true);

    try {
      if (isLogin) {
        // Attempt Spring Boot login POST /api/auth/login
        const res = await loginUser({
          email: formData.email,
          password: formData.password,
        });

        const token = res.token || res.accessToken || res.jwt || 'jwt-bearer-token-123';
        const user = res.user || {
          email: formData.email,
          name: res.name || formData.email.split('@')[0],
          role: 'CUSTOMER',
        };

        login(token, user);
        navigate('/dashboard');
      } else {
        // Attempt Spring Boot registration POST /api/auth/register
        const res = await registerUser({
          name: formData.name,
          email: formData.email,
          phone: formData.phone,
          password: formData.password,
        });

        const token = res.token || res.accessToken || 'registered-jwt-token-456';
        const user = res.user || {
          name: formData.name,
          email: formData.email,
          phone: formData.phone,
          role: 'CUSTOMER',
        };

        login(token, user);
        navigate('/dashboard');
      }
    } catch (err) {
      if (err.fieldErrors) {
        setFieldErrors(err.fieldErrors);
      }
      setGlobalError(err.message || t('generalError'));
    } finally {
      setLoading(false);
    }
  };

  const handleDemoBypass = () => {
    const demoUser = {
      name: formData.name || (formData.email ? formData.email.split('@')[0] : 'Coop Member'),
      email: formData.email || 'customer@coop.org',
      phone: formData.phone || '9876543210',
      role: 'CUSTOMER',
    };
    login('mock-demo-jwt-token', demoUser);
    navigate('/dashboard');
  };

  return (
    <div className="min-h-screen bg-slate-950 flex flex-col justify-between relative overflow-hidden">
      {/* Background Decorative Gradients */}
      <div className="absolute top-0 left-1/4 w-96 h-96 bg-emerald-600/10 rounded-full blur-3xl pointer-events-none"></div>
      <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-teal-600/10 rounded-full blur-3xl pointer-events-none"></div>

      {/* Top Navbar */}
      <header className="w-full px-6 py-4 flex items-center justify-between border-b border-slate-800/80 glass-panel z-10">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 rounded-xl gradient-button flex items-center justify-center shadow-lg shadow-emerald-900/30">
            <Building2 className="w-6 h-6 text-white" />
          </div>
          <div>
            <h1 className="text-lg font-bold text-white tracking-tight flex items-center gap-2">
              {t('appTitle')}
              <span className="text-xs px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 font-normal">
                SIH26089
              </span>
            </h1>
            <p className="text-xs text-slate-400">{t('appSubtitle')}</p>
          </div>
        </div>

        {/* Language Selector */}
        <div className="flex items-center space-x-2 bg-slate-900/80 p-1.5 rounded-xl border border-slate-800">
          <Globe className="w-4 h-4 text-emerald-400 ml-1" />
          <select
            value={language}
            onChange={(e) => setLanguage(e.target.value)}
            className="bg-transparent text-xs text-slate-200 focus:outline-none cursor-pointer pr-2 font-medium"
          >
            <option value="en" className="bg-slate-900 text-slate-200">English (EN)</option>
            <option value="hi" className="bg-slate-900 text-slate-200">हिन्दी (HI)</option>
            <option value="te" className="bg-slate-900 text-slate-200">తెలుగు (TE)</option>
          </select>
        </div>
      </header>

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 md:p-8 flex items-center justify-center z-10">
        <div className="w-full grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          
          {/* Left Hero Column */}
          <div className="lg:col-span-7 space-y-6 text-left pr-0 lg:pr-6">
            <div className="inline-flex items-center space-x-2 px-3 py-1.5 rounded-full bg-emerald-950/80 border border-emerald-500/30 text-emerald-400 text-xs font-semibold tracking-wide">
              <ShieldCheck className="w-4 h-4" />
              <span>{t('authBadge')}</span>
            </div>

            <h2 className="text-3xl md:text-5xl font-extrabold text-white leading-tight font-heading">
              {t('authHeroTitle')}
            </h2>

            <p className="text-slate-300 text-base md:text-lg leading-relaxed">
              {t('authHeroSubtitle')}
            </p>

            {/* Feature Highlights */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
              <div className="glass-card p-4 rounded-xl flex items-start space-x-3">
                <HeartHandshake className="w-6 h-6 text-emerald-400 shrink-0 mt-1" />
                <div>
                  <h4 className="text-sm font-semibold text-slate-200">5% Worker Welfare Pool</h4>
                  <p className="text-xs text-slate-400 mt-0.5">Every service transaction directly funds healthcare & emergency insurance for workers.</p>
                </div>
              </div>

              <div className="glass-card p-4 rounded-xl flex items-start space-x-3">
                <Sparkles className="w-6 h-6 text-teal-400 shrink-0 mt-1" />
                <div>
                  <h4 className="text-sm font-semibold text-slate-200">Algorithmic Match Engine</h4>
                  <p className="text-xs text-slate-400 mt-0.5">Smart matching prioritizes worker proximity, skills, and equitable task distribution.</p>
                </div>
              </div>
            </div>
          </div>

          {/* Right Auth Card Column */}
          <div className="lg:col-span-5 w-full">
            <div className="glass-panel p-6 sm:p-8 rounded-2xl shadow-2xl border border-slate-800">
              
              {/* Tab Selector */}
              <div className="flex bg-slate-900/90 p-1 rounded-xl mb-6 border border-slate-800">
                <button
                  type="button"
                  onClick={() => {
                    setIsLogin(true);
                    setGlobalError('');
                    setFieldErrors({});
                  }}
                  className={`flex-1 py-2.5 text-xs sm:text-sm font-semibold rounded-lg transition-all flex items-center justify-center space-x-2 ${
                    isLogin
                      ? 'bg-gradient-to-r from-emerald-600 to-teal-600 text-white shadow-md'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  <LogIn className="w-4 h-4" />
                  <span>{t('loginTab')}</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    setIsLogin(false);
                    setGlobalError('');
                    setFieldErrors({});
                  }}
                  className={`flex-1 py-2.5 text-xs sm:text-sm font-semibold rounded-lg transition-all flex items-center justify-center space-x-2 ${
                    !isLogin
                      ? 'bg-gradient-to-r from-emerald-600 to-teal-600 text-white shadow-md'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  <UserPlus className="w-4 h-4" />
                  <span>{t('registerTab')}</span>
                </button>
              </div>

              {/* Global Error Banner */}
              {globalError && (
                <div className="mb-5 p-3.5 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs sm:text-sm flex flex-col space-y-2">
                  <div className="flex items-start space-x-2.5">
                    <AlertCircle className="w-5 h-5 shrink-0 mt-0.5 text-rose-400" />
                    <span className="leading-snug">{globalError}</span>
                  </div>
                  
                  {/* Demo Mode Fallback Button when backend API is offline or returns 404 */}
                  <div className="pt-2 border-t border-rose-500/20">
                    <button
                      type="button"
                      onClick={handleDemoBypass}
                      className="w-full py-2 px-3 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold flex items-center justify-center space-x-1.5 transition-colors cursor-pointer"
                    >
                      <Zap className="w-3.5 h-3.5" />
                      <span>Enter Demo Dashboard Mode</span>
                    </button>
                  </div>
                </div>
              )}

              {/* Form Element */}
              <form onSubmit={handleSubmit} className="space-y-4">
                
                {/* Registration Name Field */}
                {!isLogin && (
                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                      {t('nameLabel')} *
                    </label>
                    <input
                      type="text"
                      name="name"
                      value={formData.name}
                      onChange={handleInputChange}
                      placeholder={t('namePlaceholder')}
                      className={`w-full px-3.5 py-2.5 rounded-xl text-sm glass-input ${
                        fieldErrors.name ? 'border-rose-500 focus:border-rose-500 focus:ring-rose-500/20' : ''
                      }`}
                    />
                    {fieldErrors.name && (
                      <p className="text-xs text-rose-400 mt-1 font-medium flex items-center gap-1">
                        <span>•</span> {fieldErrors.name}
                      </p>
                    )}
                  </div>
                )}

                {/* Email Address Field */}
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                    {t('emailLabel')} *
                  </label>
                  <input
                    type="email"
                    name="email"
                    value={formData.email}
                    onChange={handleInputChange}
                    placeholder={t('emailPlaceholder')}
                    className={`w-full px-3.5 py-2.5 rounded-xl text-sm glass-input ${
                      fieldErrors.email ? 'border-rose-500 focus:border-rose-500 focus:ring-rose-500/20' : ''
                    }`}
                  />
                  {fieldErrors.email && (
                    <p className="text-xs text-rose-400 mt-1 font-medium flex items-center gap-1">
                      <span>•</span> {fieldErrors.email}
                    </p>
                  )}
                </div>

                {/* Registration Phone Field */}
                {!isLogin && (
                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                      {t('phoneLabel')} *
                    </label>
                    <input
                      type="tel"
                      name="phone"
                      maxLength={10}
                      value={formData.phone}
                      onChange={handleInputChange}
                      placeholder={t('phonePlaceholder')}
                      className={`w-full px-3.5 py-2.5 rounded-xl text-sm glass-input ${
                        fieldErrors.phone ? 'border-rose-500 focus:border-rose-500 focus:ring-rose-500/20' : ''
                      }`}
                    />
                    {fieldErrors.phone && (
                      <p className="text-xs text-rose-400 mt-1 font-medium flex items-center gap-1">
                        <span>•</span> {fieldErrors.phone}
                      </p>
                    )}
                  </div>
                )}

                {/* Password Field */}
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                    {t('passwordLabel')} *
                  </label>
                  <input
                    type="password"
                    name="password"
                    value={formData.password}
                    onChange={handleInputChange}
                    placeholder={t('passwordPlaceholder')}
                    className={`w-full px-3.5 py-2.5 rounded-xl text-sm glass-input ${
                      fieldErrors.password ? 'border-rose-500 focus:border-rose-500 focus:ring-rose-500/20' : ''
                    }`}
                  />
                  {fieldErrors.password && (
                    <p className="text-xs text-rose-400 mt-1 font-medium flex items-center gap-1">
                      <span>•</span> {fieldErrors.password}
                    </p>
                  )}
                </div>

                {/* Submit Button */}
                <button
                  type="submit"
                  disabled={loading}
                  className="w-full py-3 px-4 rounded-xl text-sm font-semibold text-white gradient-button shadow-lg shadow-emerald-950/50 flex items-center justify-center space-x-2 mt-6 cursor-pointer disabled:opacity-50"
                >
                  {loading ? (
                    <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                  ) : (
                    <>
                      <span>{isLogin ? t('loginSubmit') : t('registerSubmit')}</span>
                    </>
                  )}
                </button>
              </form>

              {/* Demo Quick Start Option */}
              <div className="mt-4 pt-4 border-t border-slate-800 text-center">
                <button
                  type="button"
                  onClick={handleDemoBypass}
                  className="text-xs text-emerald-400 hover:text-emerald-300 font-medium inline-flex items-center space-x-1 cursor-pointer"
                >
                  <Zap className="w-3.5 h-3.5" />
                  <span>Preview Platform in Demo Mode (No Spring Boot required)</span>
                </button>
              </div>

              {/* Bottom Toggle Prompt */}
              <div className="mt-4 text-center text-xs text-slate-400">
                {isLogin ? t('noAccount') : t('haveAccount')}{' '}
                <button
                  type="button"
                  onClick={() => {
                    setIsLogin(!isLogin);
                    setGlobalError('');
                    setFieldErrors({});
                  }}
                  className="text-emerald-400 font-semibold hover:underline ml-1 cursor-pointer"
                >
                  {isLogin ? t('registerTab') : t('loginTab')}
                </button>
              </div>

            </div>
          </div>

        </div>
      </main>

      {/* Footer */}
      <footer className="w-full py-4 text-center text-xs text-slate-500 border-t border-slate-900 glass-panel">
        <p>SIH26089 • Cooperative Gig Services Platform • Government Backed Worker Equity Initiative</p>
      </footer>
    </div>
  );
}
