export const translations = {
  en: {
    // Navigation & Header
    appTitle: "Cooperative Gig Services",
    appSubtitle: "SIH26089 • Government Backed Worker Cooperative",
    logout: "Sign Out",
    welcomeUser: "Welcome back",
    roleCustomer: "Cooperative Member / Customer",
    
    // Auth Page
    authBadge: "Fair Wages • Shared Profits • Worker Security",
    authHeroTitle: "Democratizing Gig Work Through Worker Cooperatives",
    authHeroSubtitle: "Join India's premier cooperative platform where service workers own the profits and customers receive reliable, transparent service.",
    loginTab: "Member Sign In",
    registerTab: "New Registration",
    nameLabel: "Full Name",
    namePlaceholder: "Enter your full name",
    emailLabel: "Email Address",
    emailPlaceholder: "name@example.com",
    phoneLabel: "Mobile Phone Number",
    phonePlaceholder: "10-digit mobile number",
    passwordLabel: "Password",
    passwordPlaceholder: "••••••••",
    loginSubmit: "Sign In to Account",
    registerSubmit: "Create Cooperative Account",
    noAccount: "Don't have an account?",
    haveAccount: "Already registered?",

    // Dashboard
    dashboardTitle: "Customer Portal & Booking Hub",
    dashboardSubtitle: "Schedule certified cooperative professionals and support fair worker welfare.",
    
    // Services & Booking
    bookServiceTitle: "Book a Cooperative Service",
    selectServiceLabel: "Select Service Category",
    selectServicePlaceholder: "-- Choose a service --",
    addressLabel: "Service Location / Address",
    addressPlaceholder: "Street address, area, landmark...",
    descriptionLabel: "Work Description & Instructions",
    descriptionPlaceholder: "Describe the task, specific tools needed, or access instructions...",
    dateTimeLabel: "Schedule Date & Time",
    submitBookingBtn: "Confirm & Post Booking",
    bookingSuccessMessage: "Booking created successfully! Matching cooperative workers now...",

    // Matching Engine
    matchingTitle: "Smart Worker Matching Engine",
    matchingSubtitle: "Algorithms prioritizing skill compatibility, proximity, and fair worker allocation.",
    noMatches: "No worker matches loaded yet. Create or select an active booking to find matches.",
    matchScore: "Match Score",
    hourlyRate: "Hourly Rate",
    skillLevel: "Skill Level",
    rating: "Rating",
    verifiedCoopWorker: "Verified Cooperative Worker",
    selectWorkerBtn: "Assign Worker",

    // Job Tracker
    jobTrackerTitle: "Active & Past Job Bookings",
    jobTrackerSubtitle: "Track real-time service status, manage payments, and fund worker welfare pools.",
    bookingId: "Booking ID",
    service: "Service",
    dateTime: "Date & Time",
    status: "Status",
    action: "Action",
    noBookings: "You have no bookings recorded yet.",

    // Job Statuses
    statusPending: "Pending Match",
    statusMatched: "Worker Assigned",
    statusInProgress: "In Progress",
    statusCompleted: "Completed",
    statusCancelled: "Cancelled",

    // Payment & Welfare Flow
    settlePaymentBtn: "Settle Payment & Fund Welfare",
    paymentModalTitle: "Payment & Cooperative Welfare Contribution",
    paymentSummary: "Payment Breakdown",
    baseAmount: "Service Cost",
    welfareContribution: "Cooperative Welfare Contribution (5%)",
    totalAmount: "Total Amount Payable",
    welfareNotice: "5% of your payment is directly deposited into the Worker Welfare Security Fund to provide healthcare, insurance, and emergency grants for cooperative workers.",
    processPaymentBtn: "Pay & Allocate 5% Welfare Pool",
    paymentProcessing: "Processing Payment & Welfare Fund Transfer...",
    paymentCompleted: "Payment Successful & 5% Welfare Deposited!",

    // Rating Modal
    ratingModalTitle: "Rate Your Service Experience",
    ratingModalSubtitle: "Your feedback maintains high standards across our worker-owned cooperative network.",
    selectRating: "Select Rating (1 to 5 Stars)",
    commentsLabel: "Feedback / Review (Optional)",
    commentsPlaceholder: "Share your experience with the worker...",
    submitRatingBtn: "Submit Review",
    ratingSuccess: "Thank you! Your feedback has been submitted.",

    // Errors & Loading
    loading: "Loading...",
    submitting: "Submitting...",
    generalError: "Something went wrong. Please try again.",
  },

  hi: {
    // Navigation & Header
    appTitle: "सहकारी गिग सेवा प्लेटफॉर्म",
    appSubtitle: "SIH26089 • सरकार द्वारा समर्थित श्रमिक सहकारी",
    logout: "साइन आउट",
    welcomeUser: "स्वागत है",
    roleCustomer: "सहकारी सदस्य / ग्राहक",

    // Auth Page
    authBadge: "उचित मजदूरी • साझा लाभ • श्रमिक सुरक्षा",
    authHeroTitle: "श्रमिक सहकारिता के माध्यम से गिग कार्य का लोकतंत्रीकरण",
    authHeroSubtitle: "भारत के प्रमुख सहकारी मंच से जुड़ें जहां सेवा कर्मी लाभ के मालिक हैं और ग्राहकों को पारदर्शी सेवा मिलती है।",
    loginTab: "सदस्य साइन इन",
    registerTab: "नया पंजीकरण",
    nameLabel: "पूरा नाम",
    namePlaceholder: "अपना पूरा नाम दर्ज करें",
    emailLabel: "ईमेल पता",
    emailPlaceholder: "name@example.com",
    phoneLabel: "मोबाइल फोन नंबर",
    phonePlaceholder: "10 अंकों का मोबाइल नंबर",
    passwordLabel: "पासवर्ड",
    passwordPlaceholder: "••••••••",
    loginSubmit: "खाते में साइन इन करें",
    registerSubmit: "सहकारी खाता बनाएं",
    noAccount: "खाता नहीं है?",
    haveAccount: "पहले से पंजीकृत हैं?",

    // Dashboard
    dashboardTitle: "ग्राहक पोर्टल एवं बुकिंग हब",
    dashboardSubtitle: "प्रमाणित सहकारी पेशेवरों को शेड्यूल करें और उचित श्रमिक कल्याण का समर्थन करें।",

    // Services & Booking
    bookServiceTitle: "सहकारी सेवा बुक करें",
    selectServiceLabel: "सेवा श्रेणी चुनें",
    selectServicePlaceholder: "-- एक सेवा चुनें --",
    addressLabel: "सेवा स्थान / पता",
    addressPlaceholder: "सड़क का पता, क्षेत्र, लैंडमार्क...",
    descriptionLabel: "कार्य विवरण और निर्देश",
    descriptionPlaceholder: "कार्य, आवश्यक विशिष्ट उपकरण या पहुंच निर्देशों का वर्णन करें...",
    dateTimeLabel: "दिनांक और समय शेड्यूल करें",
    submitBookingBtn: "पुष्टि करें और बुकिंग पोस्ट करें",
    bookingSuccessMessage: "बुकिंग सफलतापूर्वक बनाई गई! अब सहकारी कर्मियों का मिलान किया जा रहा है...",

    // Matching Engine
    matchingTitle: "स्मार्ट वर्कर मैचिंग इंजन",
    matchingSubtitle: "कौशल संगतता, निकटता और उचित श्रमिक आवंटन को प्राथमिकता देने वाले एल्गोरिदम।",
    noMatches: "अभी तक कोई कार्यकर्ता मैच लोड नहीं हुआ है। मैच खोजने के लिए एक सक्रिय बुकिंग बनाएं या चुनें।",
    matchScore: "मैच स्कोर",
    hourlyRate: "प्रति घंटा दर",
    skillLevel: "कौशल स्तर",
    rating: "रेटिंग",
    verifiedCoopWorker: "सत्यापित सहकारी कार्यकर्ता",
    selectWorkerBtn: "श्रमिक असाइन करें",

    // Job Tracker
    jobTrackerTitle: "सक्रिय और पिछली नौकरी बुकिंग",
    jobTrackerSubtitle: "वास्तविक समय की सेवा स्थिति ट्रैक करें, भुगतान प्रबंधित करें और श्रमिक कल्याण कोष का पोषण करें।",
    bookingId: "बुकिंग आईडी",
    service: "सेवा",
    dateTime: "दिनांक एवं समय",
    status: "स्थिति",
    action: "कार्रवाई",
    noBookings: "आपके पास अभी तक कोई बुकिंग दर्ज नहीं है।",

    // Job Statuses
    statusPending: "लंबित मिलान",
    statusMatched: "श्रमिक आवंटित",
    statusInProgress: "प्रगति पर है",
    statusCompleted: "पूरा हुआ",
    statusCancelled: "रद्द",

    // Payment & Welfare Flow
    settlePaymentBtn: "भुगतान का निपटान करें और कल्याण कोष दें",
    paymentModalTitle: "भुगतान एवं सहकारी कल्याण योगदान",
    paymentSummary: "भुगतान विवरण",
    baseAmount: "सेवा लागत",
    welfareContribution: "सहकारी कल्याण योगदान (5%)",
    totalAmount: "कुल देय राशि",
    welfareNotice: "आपके भुगतान का 5% सीधे श्रमिक कल्याण सुरक्षा कोष में जमा किया जाता है ताकि सहकारी श्रमिकों के लिए स्वास्थ्य सेवा, बीमा और आपातकालीन अनुदान प्रदान किया जा सके।",
    processPaymentBtn: "भुगतान करें और 5% कल्याण कोष आवंटित करें",
    paymentProcessing: "भुगतान और कल्याण कोष हस्तांतरण जारी है...",
    paymentCompleted: "भुगतान सफल रहा और 5% कल्याण कोष जमा हुआ!",

    // Rating Modal
    ratingModalTitle: "अपनी सेवा अनुभव को रेट करें",
    ratingModalSubtitle: "आपकी प्रतिक्रिया हमारे श्रमिक-स्वामित्व वाले सहकारी नेटवर्क में उच्च मानकों को बनाए रखती है।",
    selectRating: "रेटिंग चुनें (1 से 5 सितारे)",
    commentsLabel: "प्रतिक्रिया / समीक्षा (वैकल्पिक)",
    commentsPlaceholder: "कार्यकर्ता के साथ अपने अनुभव को साझा करें...",
    submitRatingBtn: "समीक्षा सबमिट करें",
    ratingSuccess: "धन्यवाद! आपकी समीक्षा जमा कर दी गई है।",

    // Errors & Loading
    loading: "लोड हो रहा है...",
    submitting: "सबमिट हो रहा है...",
    generalError: "कुछ गलत हो गया। कृपया पुन: प्रयास करें।",
  },

  te: {
    // Navigation & Header
    appTitle: "సహకార గిగ్ సేవల వేదిక",
    appSubtitle: "SIH26089 • ప్రభుత్వ మద్దతు గల కార్మిక సహకార సంస్థ",
    logout: "లాగ్ అవుట్",
    welcomeUser: "స్వాగతం",
    roleCustomer: "సహకార సభ్యుడు / కస్టమర్",

    // Auth Page
    authBadge: "సమకూర్చిన వేతనాలు • పంచుకున్న లాభాలు • కార్మిక భద్రత",
    authHeroTitle: "కార్మిక సహకార సంఘాల ద్వారా గిగ్ పనుల ప్రజాస్వామ్యీకరణ",
    authHeroSubtitle: "సర్వీస్ వర్కర్లు లాభాలను పొందే భారతదేశపు ప్రసిద్ధ సహకార వేదికలో చేరండి.",
    loginTab: "సభ్యుల సైన్ ఇన్",
    registerTab: "కొత్త నమోదు",
    nameLabel: "పూర్తి పేరు",
    namePlaceholder: "మీ పూర్తి పేరును నమోదు చేయండి",
    emailLabel: "ఇమెయిల్ చిరునామా",
    emailPlaceholder: "name@example.com",
    phoneLabel: "మొబైల్ ఫోన్ నంబర్",
    phonePlaceholder: "10 అంకెల మొబైల్ నంబర్",
    passwordLabel: "పాస్‌వర్డ్",
    passwordPlaceholder: "••••••••",
    loginSubmit: "ఖాతాలోకి సైన్ ఇన్ చేయండి",
    registerSubmit: "సహకార ఖాతాను సృష్టించండి",
    noAccount: "ఖాతా లేదా?",
    haveAccount: "ఇప్పటికే నమోదయ్యారా?",

    // Dashboard
    dashboardTitle: "కస్టమర్ పోర్టల్ & బుకింగ్ హబ్",
    dashboardSubtitle: "సర్టిఫైడ్ సహకార నిపుణులను షెడ్యూల్ చేయండి మరియు కార్మిక సంక్షేమానికి మద్దతు ఇవ్వండి.",

    // Services & Booking
    bookServiceTitle: "సహకార సేవను బుక్ చేయండి",
    selectServiceLabel: "సేవా వర్గాన్ని ఎంచుకోండి",
    selectServicePlaceholder: "-- ఒక సేవను ఎంచుకోండి --",
    addressLabel: "సేవా స్థలం / చిరునామా",
    addressPlaceholder: "వీధి చిరునామా, ప్రాంతం, ల్యాండ్‌మార్క్...",
    descriptionLabel: "పని వివరణ మరియు సూచనలు",
    descriptionPlaceholder: "పని, అవసరమైన నిర్దిష్ట సాధనాలు వివరించండి...",
    dateTimeLabel: "తేదీ & సమయాన్ని షెడ్యూల్ చేయండి",
    submitBookingBtn: "ధృవీకరించండి & బుకింగ్‌ను పోస్ట్ చేయండి",
    bookingSuccessMessage: "బుకింగ్ విజయవంతంగా పూర్తయింది!",

    // Matching Engine
    matchingTitle: "స్మార్ట్ వర్కర్ మ్యాచింగ్ ఇంజిన్",
    matchingSubtitle: "నైపుణ్యం మరియు దూరం ఆధారంగా వర్కర్ మ్యాచింగ్.",
    noMatches: "ఇంకా వర్కర్ మ్యాచ్‌లు లోడ్ కాలేదు.",
    matchScore: "మ్యాచ్ స్కోర్",
    hourlyRate: "గంట సగటు రేటు",
    skillLevel: "నైపుణ్య స్థాయి",
    rating: "రేటింగ్",
    verifiedCoopWorker: "ధృవీకరించబడిన సహకార వర్కర్",
    selectWorkerBtn: "వర్కర్‌ను కేటాయించండి",

    // Job Tracker
    jobTrackerTitle: "యాక్టివ్ & గత జాబ్ బుకింగ్‌లు",
    jobTrackerSubtitle: "రియల్ టైమ్ సేవా స్థితిని ట్రాక్ చేయండి మరియు సంక్షేమ నిధికి సహకరించండి.",
    bookingId: "బుకింగ్ ID",
    service: "సేవ",
    dateTime: "తేదీ & సమయం",
    status: "స్థితి",
    action: "చర్య",
    noBookings: "మీకు ఇంకా బుకింగ్‌లు లేవు.",

    // Job Statuses
    statusPending: "పెండింగ్ మ్యాచ్",
    statusMatched: "వర్కర్ కేటాయించబడ్డారు",
    statusInProgress: "పురోగతిలో ఉంది",
    statusCompleted: "పూర్తయింది",
    statusCancelled: "రద్దు చేయబడింది",

    // Payment & Welfare Flow
    settlePaymentBtn: "చెల్లింపు చెల్లించండి & సంక్షేమ నిధి ఇవ్వండి",
    paymentModalTitle: "చెల్లింపు మరియు సహకార సంక్షేమ కాంట్రిబ్యూషన్",
    paymentSummary: "చెల్లింపు వివరాలు",
    baseAmount: "సేవా ధర",
    welfareContribution: "సహకార సంక్షేమ విరాళం (5%)",
    totalAmount: "మొత్తం చెల్లించాల్సిన మొత్తం",
    welfareNotice: "మీ చెల్లింపులో 5% నేరుగా వర్కర్ వెల్ఫేర్ సెక్యూరిటీ ఫండ్‌లో జమ చేయబడుతుంది.",
    processPaymentBtn: "చెల్లించండి & 5% సంక్షేమ నిధి కేటాయించండి",
    paymentProcessing: "చెల్లింపు ప్రాసెసింగ్ జరుపుతోంది...",
    paymentCompleted: "చెల్లింపు విజయవంతమైంది!",

    // Rating Modal
    ratingModalTitle: "మీ సేవా అనుభవాన్ని రేట్ చేయండి",
    ratingModalSubtitle: "మీ అభిప్రాయం మా వర్కర్ సహకార సంఘానికి సహాయపడుతుంది.",
    selectRating: "రేటింగ్ ఎంచుకోండి (1 నుండి 5 నక్షత్రాలు)",
    commentsLabel: "అభిప్రాయం / సమీక్ష",
    commentsPlaceholder: "వర్కర్‌తో మీ అనుభవాన్ని పంచుకోండి...",
    submitRatingBtn: "సమీక్షను సమర్పించండి",
    ratingSuccess: "ధన్యవాదాలు! మీ సమీక్ష సమర్పించబడింది.",

    // Errors & Loading
    loading: "లోడ్ అవుతోంది...",
    submitting: "సమర్పిస్తోంది...",
    generalError: "ఏదో పొరపాటు జరిగింది. దయచేసి మళ్లీ ప్రయత్నించండి.",
  }
};
